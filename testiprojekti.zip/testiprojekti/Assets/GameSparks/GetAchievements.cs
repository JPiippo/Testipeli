﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GameSparks.Api;
using GameSparks.Api.Requests;
using GameSparks.Api.Responses;
using GameSparks.Core; 

public class GetAchievements : MonoBehaviour
{
    // Tämä skripti demonstroi, kuinka GameSparksista voidaan hakea pelaajan tietoja, kuten saatuja
    //Achievementejä.
    public void GetAchievementData()
    {
        ///Luodaan valmiiksi uusi lista, johon achievementit haetaan.
        List<string> achievementsLista = new List<string>();

       new GameSparks.Api.Requests.AccountDetailsRequest().Send((vastaus) => {
            if (!vastaus.HasErrors) {
                Debug.Log("Noudetaan käyttäjätilin tietoja...");
                string pName = vastaus.DisplayName; // Haetaan näyttönimi
                 Debug.Log("Kirjautuneen pelaajan nimi: " + pName);
                achievementsLista = vastaus.Achievements; // Haetaan listana saadut achievementit.
                GSData valuutat = vastaus.Currencies;
                long? valuutta1 = vastaus.Currency1;
                
                foreach(string s in achievementsLista) {
                    Debug.Log("Tililläsi on saatu achievement: " + s);
                }
                    Debug.Log("Tililläsi on valuuttaa " + valuutta1);
            } 
            
            else {
                Debug.Log("Tapahtui virhe tietojen haussa...");
            }
        });  



    }

    
}
