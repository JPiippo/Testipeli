﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

///Tämä skripti on käytössä kirjautumis-painikkeessa. AuthorizePlayer lähettää
///GameSparksille AuthenticationRequest-pyynnön, jossa se tarkastaa käyttäjän syöttämät
///kirjautumistiedot. Mikäli virheitä ei ole, siirrytään seuraavaan Sceneen ja kirjautuminen pysyy voimassa.
///

public class AuthorizePlayerButton : MonoBehaviour
{

    public Text displayNameInput, userNameInput, passwordInput;
    
    public void AuthorizePlayer()
    {

        Debug.Log("GameSparks tarkastaa syötettyjä tietoja...");
        new GameSparks.Api.Requests.AuthenticationRequest()
            .SetUserName(userNameInput.text)
            .SetPassword(passwordInput.text)
            .Send((vastaus) =>
           {

               ///Jos GameSparkista saadussa vastauksessa ei ole virheitä ja kirjautuminen onnistuu
               ///siirrytään seuraavaan sceneen.
               if (!vastaus.HasErrors)
               {
                   Debug.Log("Pelaaja tunnistettu... Tunnus: " + vastaus.DisplayName);                   
                
                ///Kirjautumisen jälkeen ladataan seuraava scene    
                Application.LoadLevel("MenuScene");
                  
                   
               }

                ///Mikäli AuthenticationRequest epäonnistuu, ilmoitetaan lokiin kirjautumisen epäonnistumisesta
               else
               {
                   Debug.Log("Tapahtui virhe, tarkista kirjautumistiedot.");
                   
               }

           });

    }

   
    

}
