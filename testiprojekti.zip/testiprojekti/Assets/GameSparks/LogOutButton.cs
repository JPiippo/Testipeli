﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GameSparks.Api;
using GameSparks.Api.Requests;
using GameSparks.Api.Responses;
using GameSparks.Core;

///Tämä skripti on käytössä uloskirjautumispainikkeessa. GS.Disconnect kirjaa käyttäjän ulos
///Uloskirjautumisen jälkeen pyyntöjä ei voida enää lähettää ja käyttäjän tulee kirjautua
///sisään uudestaan.

public class LogOutButton : MonoBehaviour
{
    // Start is called before the first frame update
   public void LogOut()
    {
        
        GS.Disconnect();
        Debug.Log("Käyttäjä kirjattu ulos");
        Application.LoadLevel("LoginScene");
        

        
    }

    
}
