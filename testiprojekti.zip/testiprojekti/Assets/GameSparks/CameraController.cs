﻿        using UnityEngine;
        using System.Collections;
         
        public class CameraController : MonoBehaviour
        {
            public Transform player;
           
            void Start()
            {
         
            }
         
            void Update()
            {
                transform.position = new Vector3 (-221, player.position.y, transform.position.z);
            }
        }
         

     

