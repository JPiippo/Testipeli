﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

///Tätä skriptiä käyteään rekisteröitymispainikkeessa. Kun painiketta klikataan 
///suoritetaan RegisterPlayer() ja lähetetään GameSparksille RegistrationRequest-pyyntö. 
///Mikäli virheitä ei tapahdu, suoritetaan rekisteröinti loppuun ja käyttäjä voi kirjautua heti palveluun. Muussa tapauksessa
///lokiin tulostetaan virheilmoitus. 
public class RegisterPlayerButton : MonoBehaviour
{

    public Text displayNameInput, userNameInput, passwordInput;

    public void RegisterPlayer()
    {

        Debug.Log("Tarkastetaan syötettyjä tietoja...");
        new GameSparks.Api.Requests.RegistrationRequest()
            .SetDisplayName(displayNameInput.text)
            .SetUserName(userNameInput.text)
            .SetPassword(passwordInput.text)
            .Send((vastaus) =>
            {

                if (!vastaus.HasErrors)
                {
                    Debug.Log("Uusi pelaaja rekisteröity tunnuksella: " + vastaus.DisplayName);
                }

                else
                {
                    Debug.Log("Rekisteröitymisessä tapahtui virhe.");
                }

            });

    }

    

}
