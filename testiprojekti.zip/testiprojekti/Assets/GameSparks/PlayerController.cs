﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

///Tämä skripti on käytössä pelihahmossa. Skripti määrittelee pelaajan liikkumisen, sekä
///laskee kerätyt pisteet. Pelin lopussa kun pelaaja pääsee maaliin, lähetetään pisteet
///GameSparksiin aiemmin luodulla Eventillä "PLAYER_TO_LEADERBOARD". LogEventRequest
///lähettää tiedot eteenpäin kun pelaaja osuu "maali"-nimiseen GameObjectiin.
///Tämän jälkeen haetaan GameSparksista parhaat pisteet saaneet pelaajat GameSparksin 
///LeaderBoardDataRequest-pyynnöllä. Peli tulostaa lokiin parhaiten sijoittuneet pelaajat,
///heidän sijoituksensa sekä saadut pisteet.


public class PlayerController : MonoBehaviour
{
public Rigidbody2D dbody;
public float movespeed;
private int score;
public Text scoreCounter;
float horizontal;
float vertical;
    // Start is called before the first frame update
    void Start()
    {
        dbody = GetComponent<Rigidbody2D>();
        score = 0;
        scoreCounter.text = "Score: " + score.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        horizontal = Input.GetAxisRaw("Horizontal");
        vertical = Input.GetAxisRaw("Vertical"); 

        
    }

    private void FixedUpdate()
{  
   dbody.velocity = new Vector2(horizontal * movespeed, vertical * movespeed);

  

}
   void OnCollisionEnter2D (Collision2D col) 
    {
        //Alla olevassa skriptissä on kuvattu pelaajan pisteiden kerääminen. Pelaajan osuessa 
        //timantti-nimiseen peliobjektiin, saa pelaaja yhden pisteen lisää. 
         if(col.gameObject.name == "timantti")
        {
            score = score + 1;
            Destroy(col.gameObject);
            scoreCounter.text = "Score: " + score.ToString();
        }

        if(col.gameObject.name == "maali")
        {
            
             Destroy(col.gameObject);

            Debug.Log("Lähetetään pisteitä GameSparksin Leaderboardille...");
            new GameSparks.Api.Requests.LogEventRequest()
            .SetEventKey("PLAYER_TO_LEADERBOARD")
            .SetEventAttribute("PLAYER_SCORES", score)
            .Send((vastaus) =>
           {

               if (!vastaus.HasErrors)
               {
                Debug.Log("Pisteet tallennettu. Lopulliset pisteet: " +score);

               }

               else
               {
                   Debug.Log("Tapahtui virhe pisteiden tallennuksessa.");
                   
               }

           });

        }

    //Alla oleva skripti suoritetaan kun pelaaja pääsee maaliin. Se hakee GameSparksista Leaderboardin 10
    //Eniten pisteitä saanutta pelaajaa.

        if(col.gameObject.name == "maali2")
        {

             new GameSparks.Api.Requests.LeaderboardDataRequest()
                .SetEntryCount(10)
                .SetLeaderboardShortCode("SCORE_BOARD")
                .Send((vastaus) =>
                {

                if(!vastaus.HasErrors)
					{
                         Destroy(col.gameObject);
						
                        //Loop käy läpi jokaisen elementenin vastaanotetusta datasta. Nämä ovat tyyppiä LeaderboardData.
						foreach(GameSparks.Api.Responses.LeaderboardDataResponse._LeaderboardData lb in vastaus.Data)
						{ 
							int pRank = int.Parse(lb.Rank.ToString()); //Haetaan pelaajan sijoitus saadusta vastauksesta
							string pName = lb.UserName; //Haetaan pelaajan nimi saadusta vastauksesta
							string pScore = lb.JSONData["PLAYER_SCORES"].ToString(); //PLAYER_SCORES = pelaajan saamat pisteet. Tämä on event, joka luotiin aiemmin itse GS:n portaalissa.
							
							//Alla printataan vastaanotettu data Unityn lokiin. 
							string outPut =  "Rank:"+pRank+"\n  "+"Name: "+pName+"  "+"Score: "+pScore;
							Debug.Log(outPut); 
						}
					}

                });

            


        }

        //Mikäli pelaaja kerää kentän lopussa olevan kultaisen timantin, annetaan hänelle
        //+1 virtuaalivaluuttaa lisää alla olevalla LogEventRequestilla. Eventinä käytetään
        //Aiemmin luotua ADD_VALUUTTA eventiä, jonka attribuutti tallentaa pelaajan tietoihin
        //virtuaalivaluuttojen summan, eli aina kun kerätään kyseinen objekti nousee pelaajan
        //virtuaalivaluutta yhdellä. 
        if(col.gameObject.name == "Virtuaalivaluutta_objekti")
        {
            Destroy(col.gameObject);
            new GameSparks.Api.Requests.LogEventRequest()
            .SetEventKey("ADD_VALUUTTA")
            .SetEventAttribute("ADD_VL", 1)
            .Send((vastaus) =>
           {

               if (!vastaus.HasErrors)
               {
                
                Debug.Log("Pelaajalle on nyt annettu +1 virtuaalivaluuttaa");

               }

               else
               {
                   Debug.Log("Tapahtui virhe.");
                   
               }

           });
        }
        
    }
  


}
