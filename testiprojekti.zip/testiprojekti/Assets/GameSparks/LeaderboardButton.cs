﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeaderboardButton : MonoBehaviour
{
    // Start is called before the first frame update
    public void GetLeaderboard()
    {
        
           new GameSparks.Api.Requests.LeaderboardDataRequest()
                .SetEntryCount(10) //SetEntryCount-kohtaan voidaan määrittää kuinka monen kärkipelaajan tiedot haetaan. Tässä haetaan Top10.
                .SetLeaderboardShortCode("SCORE_BOARD") //Tähän valitaan leaderboard, josta tietoja halutaan hakea. Käytetään aiemmin määriteltyä "Short Code"-tunnistetta.
                .Send((vastaus) => //Lähetetään pyyntö ja saadaan vastaus.
                {

                //Mikäli pyynnön vastaus ei ole virheellinen suoritetaan alla oleva skripti:
                if(!vastaus.HasErrors)
					{
						
                        //Loop käy läpi jokaisen elementenin vastaanotetusta datasta. Nämä ovat tyyppiä LeaderboardData.
						foreach(GameSparks.Api.Responses.LeaderboardDataResponse._LeaderboardData lb in vastaus.Data)
						{ 
							int pRank = int.Parse(lb.Rank.ToString()); //Haetaan pelaajan sijoitus saadusta vastauksesta
							string pName = lb.UserName; //Haetaan pelaajan nimi saadusta vastauksesta
							string pScore = lb.JSONData["PLAYER_SCORES"].ToString(); //PLAYER_SCORES = pelaajan saamat pisteet. Tämä on event, joka luotiin aiemmin itse GS:n portaalissa.
							
							//Alla printataan vastaanotettu data Unityn lokiin. 
							string outPut =  "Rank:"+pRank+"\n  "+"Name: "+pName+"  "+"Score: "+pScore;
							Debug.Log(outPut); 
						}
					}

                    else {
                        Debug.Log("Leaderboard tietojen haussa tapahtui virhe.");
                    }


                });

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
