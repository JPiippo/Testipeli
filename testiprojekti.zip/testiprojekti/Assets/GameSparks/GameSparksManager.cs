﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// Skripti tarkistaa ettei koskaan ole kahta GameSparksManageria samaan aikaan päällä.
/// </summary>
public class GameSparksManager : MonoBehaviour
{

    private static GameSparksManager instance = null;
   
    void Awake()
    {
        
        if (instance == null)
        {

            instance = this;
            DontDestroyOnLoad(this.gameObject);

        }
        else
        {
            Destroy(this.gameObject);
        }
    }
    
}
