﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AloitaPeli : MonoBehaviour
{
    // Skripti on käytössä painikkeessa, jolla ladataan peliscene. 
    public void Aloita()
    {

        


        Application.LoadLevel("PeliScene");
    }

    
}
