﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnnaValuuttaa : MonoBehaviour
{
    //Alla oleva skripti antaa pelaajalle yhden virtuaalirahan lisää.
    public void LisääRahaa ()

    {
        new GameSparks.Api.Requests.LogEventRequest()
            .SetEventKey("ADD_VALUUTTA")
            .SetEventAttribute("ADD_VL", 1)
            .Send((vastaus) =>
           {

               if (!vastaus.HasErrors)
               {
                Debug.Log("Pelaajalle on nyt annettu +1 virtuaalivaluuttaa");

               }

               else
               {
                   Debug.Log("Tapahtui virhe.");
                   
               }

           });
    }


    
    
    
}
